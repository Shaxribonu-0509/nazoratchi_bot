# Nazoratchi Telegram Bot

Bu bot mahsulotlaringizni nazorat qilish uchun yaratilgan. U qoʻshilgan sana, yaroqlilik muddati va mahsulot turiga qarab saralaydi.