
import sqlite3
from datetime import datetime

def init_db():
    conn = sqlite3.connect('products.db')
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY,
            name TEXT,
            category TEXT,
            added_date TEXT,
            expiry_date TEXT
        )
    """)
    conn.commit()
    conn.close()

def add_product(name, category, added_date, expiry_date):
    conn = sqlite3.connect('products.db')
    c = conn.cursor()
    c.execute("INSERT INTO products (name, category, added_date, expiry_date) VALUES (?, ?, ?, ?)",
              (name, category, added_date, expiry_date))
    conn.commit()
    conn.close()

def get_all_products():
    conn = sqlite3.connect('products.db')
    c = conn.cursor()
    c.execute("SELECT * FROM products")
    data = c.fetchall()
    conn.close()
    return data

def get_soon_expiring_products(days=5):
    conn = sqlite3.connect('products.db')
    c = conn.cursor()
    today = datetime.today()
    c.execute("SELECT * FROM products")
    data = []
    for row in c.fetchall():
        expiry = datetime.strptime(row[4], "%d.%m.%Y")
        if 0 <= (expiry - today).days <= days:
            data.append(row)
    conn.close()
    return data
