
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from database import init_db, add_product, get_all_products, get_soon_expiring_products
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")

NAME, CATEGORY, ADDED_DATE, EXPIRY_DATE = range(4)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Salom! Bu nazoratchi bot. /add bilan mahsulot qo‘shing.")

async def add_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("1️⃣ Mahsulot nomini kiriting:")
    return NAME

async def add_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text
    await update.message.reply_text("2️⃣ Kategoriyasini kiriting (masalan: oziq-ovqat, kosmetika, dori):")
    return CATEGORY

async def add_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["category"] = update.message.text
    await update.message.reply_text("3️⃣ Qo‘shilgan sanani kiriting (masalan: 30.04.2025):")
    return ADDED_DATE

async def add_added_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["added_date"] = update.message.text
    await update.message.reply_text("4️⃣ Yaroqlilik muddatini kiriting (masalan: 05.05.2025):")
    return EXPIRY_DATE

async def add_expiry_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["expiry_date"] = update.message.text
    add_product(
        context.user_data["name"],
        context.user_data["category"],
        context.user_data["added_date"],
        context.user_data["expiry_date"],
    )
    await update.message.reply_text("✅ Mahsulot qo‘shildi!")
    return ConversationHandler.END

async def list_products(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = get_all_products()
    msg = "\n\n".join([f"{d[1]} | {d[2]} | Qo‘shilgan: {d[3]} | Tugash: {d[4]}" for d in data])
    await update.message.reply_text(msg or "Mahsulotlar mavjud emas.")

async def soon_expiring(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = get_soon_expiring_products()
    msg = "\n\n".join([f"{d[1]} | {d[2]} | Tugash: {d[4]}" for d in data])
    await update.message.reply_text(msg or "Yaqin kunlarda muddati tugaydigan mahsulot yo‘q.")

if __name__ == "__main__":
    init_db()
    app = ApplicationBuilder().token(TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("add", add_start)],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_name)],
            CATEGORY: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_category)],
            ADDED_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_added_date)],
            EXPIRY_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_expiry_date)],
        },
        fallbacks=[],
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(conv_handler)
    app.add_handler(CommandHandler("list", list_products))
    app.add_handler(CommandHandler("soon", soon_expiring))

    print("Bot ishga tushdi...")
    app.run_polling()
